// Copyright (C) Mike Svendsen and Arko Provo Mukherjee
// For questions contact Prof. Srikanta Tirthapura (snt@iastate.edu)

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Reducer;

public class DegreeRed extends Reducer<LongWritable, Text, LongWritable, Text>{

	//Keys of subgraph are neighbors to v
	//Values associated with key u are the neighbors of u
	private HashMap<LongWritable, LinkedList<LongWritable>> SubGraph;
	
	private boolean randomOrder;	// True if using a random ordering
	private boolean degOrder;		// True if using degree ordering
	private Random rand;
	private HashMap<Long, Long> vertexOrder;	// Ordering of vertices
	private int MAXRAND = 2147483647;
	
	/**
	 * This function is automatically called when configuring Map task
	 * @param Context context
	 */
	@Override
	public void setup(Context context)
	{
		Configuration conf = context.getConfiguration();
		String strRandomOrder = conf.get("RandomOrder");
		String strDegOrder = conf.get("DegreeOrder");
		if(Integer.parseInt(strRandomOrder) == 1)
			randomOrder = true;
		else
			randomOrder = false;
		
		if(Integer.parseInt(strDegOrder) == 1){
			degOrder    = true;
			randomOrder = false;
		}
		else {
			degOrder    = false;
			randomOrder = false;
		}
		rand = new Random();
	}
	
	@Override
	protected void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException
	{
		//Key = a node v
		//Values = neighbor u of v + neighbors of u
		String strCcur = key.toString();	//Current clique being processed
		
		SubGraph = new HashMap<LongWritable, LinkedList<LongWritable>>();
		vertexOrder = new HashMap<Long, Long>();
		
		// Add the keys rank to the ordering
		if(randomOrder)
		{
			// Set seed as key to ensure consistent ordering across reducers
			rand.setSeed(key.get());
			vertexOrder.put(key.get(), (long)rand.nextInt(MAXRAND));
		}
		else if(degOrder)
		{
			// do nothing
		}else
		{
			vertexOrder.put(key.get(), key.get());
		}
		
		Iterator<Text> iter = values.iterator();
		while(iter.hasNext())
		{
			String line = iter.next().toString();	//Get line
			StringTokenizer tokenLine = new StringTokenizer(line);			//Split into tokens
			LongWritable vNeighbor = new LongWritable(Long.parseLong(tokenLine.nextToken()));	//First token is neighbor of v;
			if(randomOrder)
			{
				// Set seed to ensure consistent ordering across reducers
				rand.setSeed(vNeighbor.get());
				vertexOrder.put(vNeighbor.get(), (long)rand.nextInt(MAXRAND));
			}
			else
			{
				vertexOrder.put(vNeighbor.get(), vNeighbor.get());
			}
			
			
			long ivNeighbor = vNeighbor.get();
			
			LinkedList<LongWritable> vTwoHop = new LinkedList<LongWritable>();	//Rest of tokens are neighbors of vNeighbor
			while(tokenLine.hasMoreTokens())
			{
				LongWritable next = new LongWritable(Long.parseLong(tokenLine.nextToken()));
				long iNext = next.get();
				if(iNext != ivNeighbor) vTwoHop.add(next);		//Mapper included u in the list of u's neighbors
			}
			if(degOrder)
				vertexOrder.put(ivNeighbor, new Long(vTwoHop.size()));
			SubGraph.put(vNeighbor, vTwoHop);
		}
		//SubGraph.put(key, neighbors);
		if(degOrder)
			vertexOrder.put(key.get(), new Long(SubGraph.keySet().size()));
		
		//TODO:  We may be able to ignore neighbors of key
		HashSet<LongWritable> CAND = new HashSet<LongWritable>(SubGraph.keySet());
		HashSet<LongWritable> FINI = new HashSet<LongWritable>();
		CAND.remove(key);
		// Remove any vertices which are not direct neighbors
		Set<LongWritable> neighbors = SubGraph.keySet();
		neighbors.remove(key);
		for(LongWritable u : neighbors)
		{
			LinkedList<LongWritable> uNeighbors = SubGraph.get(u);
			uNeighbors.retainAll(neighbors);			
			if(vertexOrder.get(u.get()) < vertexOrder.get(key.get()) ||
				(vertexOrder.get(u.get()).equals(vertexOrder.get(key.get())) && u.get() < key.get()))
			{
				CAND.remove(u);
				FINI.add(u);
			}
		}
		
		expand(FINI, CAND, key, strCcur, 1, context);		//Find all cliques key is part of
		
	}
	
	/**
	 * Find all cliques that strCcur is involved in
	 * @param SUBG - All neighbors u along with u's neighbors, such that u is a neighbor of every node in the current clique
	 * @param CAND - The most recently added node to the current clique
	 * @param strCcur - A string containing the nodes in the current clique
	 * @param iCcurSize - size of the current clique
	 * @param reporter - Reporter used for reporting size and number of cliques found
	 * @return The list of all cliques found after the call to this function
	 * @throws InterruptedException 
	 * @throws IOException 
	 */
	private void expand(	Set<LongWritable> FINI, 
							Set<LongWritable> CAND, LongWritable key,
							String strCcur, int iCcurSize, 
							Context context) throws IOException, InterruptedException {
		
		context.setStatus("W" + iCcurSize);//"Processing: " + strCcur);	//report progress so task isn't deemed failed.
	
		//Create images of current state
		String strCcurImage = new String(strCcur);
		
		int currentSize = iCcurSize;
		
		if(FINI.isEmpty() && CAND.isEmpty())		// Line 2
		{			
			//strCall += "\n\t" + strCcur;		//Only output cliques larger than min_clique_size
			report_size(context, currentSize);
			context.write(key, new Text(strCcur));
			return;// strCall;
		}
		else if(CAND.isEmpty())
		{
			return;// strCall;
		}
		else
		{
			//Line 4
			LongWritable u = maxIntersection(FINI, CAND);
			HashSet<LongWritable> EXT = new HashSet<LongWritable>(CAND);
			EXT.removeAll(SubGraph.get(u));			//EXT = CAND - N(u)
			//HashSet<LongWritable> FINI = new HashSet<LongWritable>();
			
			while(!EXT.isEmpty())		//Line 5
			{
				LongWritable q = EXT.iterator().next();		//Line 6
				strCcur += " " + q.toString();				//Line 7
				currentSize++; 
				
				//Line 8
				HashSet<LongWritable> FINIq = new HashSet<LongWritable>(FINI);
				FINIq.retainAll(SubGraph.get(q));	
				
				//Line 9
				HashSet<LongWritable> CANDq = new HashSet<LongWritable>(CAND);
				CANDq.retainAll(SubGraph.get(q));
				
				//Line 10
				expand(FINIq, CANDq, key, strCcur, currentSize, context);
				
				//Line 11
				CAND.remove(q);
				FINI.add(q);
				EXT.remove(q);
				currentSize--;
				
				//Line 12
				strCcur = strCcurImage;
			}
			
		}
		return;
	}

	// Assume all neighbors of a vertex must be contained in SUBG
	// It is assumed each linked list is sorted from smallest to largest
	private LongWritable maxIntersection( Set<LongWritable> FINI, Set<LongWritable> CAND) 
	{
		LongWritable max = null;
		int maxInterSize = -1;
		
		for(LongWritable u : FINI)
		{
			LinkedList<LongWritable> uNeighbor = SubGraph.get(u);
			if(maxInterSize == -1)
				max = u;
			if(uNeighbor.isEmpty())
				continue;
			
			int uSize = uNeighbor.size();
			int candSize = CAND.size();
			int uCount = 0;
			int candCount = 0;
			
			Iterator<LongWritable> uIter = uNeighbor.iterator();
			Iterator<LongWritable> cIter = CAND.iterator();
			long neigh = -1;
			long cand = -1;
			
			while(uCount < uSize)
			{
				if(uCount == 0)	// Base case
				{
					neigh = uIter.next().get();
					if(candCount < candSize)
						cand = cIter.next().get();
					else 
					{
						uCount = uSize;
						continue;
					}
					uCount++;
					candCount++;
				}
				
				if(neigh == cand)
				{
					if(uCount < uSize)
					{
						uCount++;
						neigh = uIter.next().get();
					}
					if(candCount < candSize)
					{
						candCount++;
						cand = cIter.next().get();
					}
					else	// Last cand matched therefore no more to look at so escape
					{
						uCount = uSize;
					}
				}
				else if(neigh < cand)
				{
					if(uCount < uSize)
					{
						uCount++;
						neigh = uIter.next().get();
					}
				}
				else // cand < neigh
				{
					if(candCount < candSize)
					{
						candCount++;
						cand = cIter.next().get();
					}
					else	// cand < neigh but out of candidates
					{
						uCount = uSize;		//Escape this while loop
					}
				}
				
				
			} //End While
			
			if(uSize > maxInterSize)
			{
				maxInterSize = uSize;
				max = u;
			}
		} // End For
		
		for(LongWritable u : CAND)
		{
			LinkedList<LongWritable> uNeighbor = SubGraph.get(u);
			if(maxInterSize == -1)
				max = u;
			if(uNeighbor.isEmpty())
				continue;
			
			int uSize = uNeighbor.size();
			int candSize = CAND.size();
			int uCount = 0;
			int candCount = 0;
			
			Iterator<LongWritable> uIter = uNeighbor.iterator();
			Iterator<LongWritable> cIter = CAND.iterator();
			long neigh = -1;
			long cand = -1;
			
			while(uCount < uSize)
			{
				if(uCount == 0)	// Base case
				{
					neigh = uIter.next().get();
					if(candCount < candSize)
						cand = cIter.next().get();
					else 
					{
						uCount = uSize;
						continue;
					}
					uCount++;
					candCount++;
				}
				
				if(neigh == cand)
				{
					if(uCount < uSize)
					{
						uCount++;
						neigh = uIter.next().get();
					}
					if(candCount < candSize)
					{
						candCount++;
						cand = cIter.next().get();
					}
					else	// Last cand matched therefore no more to look at so escape
					{
						uCount = uSize;
					}
				}
				else if(neigh < cand)
				{
					if(uCount < uSize)
					{
						uCount++;
						neigh = uIter.next().get();
					}
				}
				else // cand < neigh
				{
					if(candCount < candSize)
					{
						candCount++;
						cand = cIter.next().get();
					}
					else	// cand < neigh but out of candidates
					{
						uCount = uSize;		//Escape this while loop
					}
				}
				
				
			} //End While
			
			if(uSize > maxInterSize)
			{
				maxInterSize = uSize;
				max = u;
			}
		} // End For
		
		return max;
		
	}

	/**
	 * Report the size of the clique
	 * @param context - Reporter for reporting the size of the current clique
	 * @param currentSize - Size of the clique being reported
	 */
	private void report_size(Context context, int currentSize) {
		String counterName = "Clique of size ";
		counterName += currentSize;
		
		Counter counter = context.getCounter("CliqueSizeAndNum", counterName);
		counter.increment(1);
		
	}
}